import { pgTable, text, serial, timestamp, numeric, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const employeesTable = pgTable("employees", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  cpf: text("cpf").notNull(),
  matricula: text("matricula").notNull(),
  dataAdmissao: text("data_admissao").notNull(),
  dataDesligamento: text("data_desligamento").notNull(),
  motivoDesligamento: text("motivo_desligamento").notNull(),
  cargo: text("cargo").notNull(),
  salario: numeric("salario", { precision: 15, scale: 2 }).notNull(),
  avisosPrevios: text("avisos_previos"),
  fgtsValor: numeric("fgts_valor", { precision: 15, scale: 2 }),
  fgtsMes: text("fgts_mes"),
  cliente: text("cliente"),
  transmissionId: integer("transmission_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertEmployeeSchema = createInsertSchema(employeesTable).omit({ id: true, createdAt: true });
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employeesTable.$inferSelect;
