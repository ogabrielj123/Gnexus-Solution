import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const clientesAdminTable = pgTable("clientes_admin", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  cnpj: text("cnpj"),
  email: text("email"),
  telefone: text("telefone"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const escritoriosTable = pgTable("escritorios", {
  id: serial("id").primaryKey(),
  nome: text("nome").notNull(),
  clienteId: integer("cliente_id").notNull().references(() => clientesAdminTable.id, { onDelete: "cascade" }),
  email: text("email"),
  telefone: text("telefone"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertClienteAdminSchema = createInsertSchema(clientesAdminTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertClienteAdmin = z.infer<typeof insertClienteAdminSchema>;
export type ClienteAdmin = typeof clientesAdminTable.$inferSelect;

export const insertEscritorioSchema = createInsertSchema(escritoriosTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertEscritorio = z.infer<typeof insertEscritorioSchema>;
export type Escritorio = typeof escritoriosTable.$inferSelect;
