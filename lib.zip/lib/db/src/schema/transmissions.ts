import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";

import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const transmissionsTable = pgTable("transmissions", {
  id: serial("id").primaryKey(),
  cnpjEmpregador: text("cnpj_empregador").notNull(),
  ambiente: text("ambiente").notNull(),
  status: text("status").notNull().default("pending"),
  eventType: text("event_type").notNull(),
  employeeCount: integer("employee_count").notNull().default(0),
  protocoloEsocial: text("protocolo_esocial"),
  errorMessage: text("error_message"),
  xmlS2500: text("xml_s2500"),
  xmlS2501: text("xml_s2501"),
  xmlAssinadoS2500: text("xml_assinado_s2500"),
  xmlAssinadoS2501: text("xml_assinado_s2501"),
  consultaResponse: text("consulta_response"),
  consultaStatus: text("consulta_status"),
  consultaAt: timestamp("consulta_at", { withTimezone: true }),
  extraData: text("extra_data"),
  certificateId: integer("certificate_id"),
  formId: integer("form_id"),
  sentAt: timestamp("sent_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTransmissionSchema = createInsertSchema(transmissionsTable).omit({ id: true, createdAt: true });
export type InsertTransmission = z.infer<typeof insertTransmissionSchema>;
export type Transmission = typeof transmissionsTable.$inferSelect;
