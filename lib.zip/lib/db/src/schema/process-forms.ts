import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const processFormsTable = pgTable("process_forms", {
  id: serial("id").primaryKey(),

  // Etapa 0 — Escritório
  cliente: text("cliente"),
  escritorioInformante: text("escritorio_informante"),

  // Etapa 1 — Identificação do Processo
  origemProcesso: text("origem_processo"),
  numeroProcesso: text("numero_processo"),
  temObservacoes: text("tem_observacoes"),
  observacoes: text("observacoes"),
  dataDecisao: text("data_decisao"),
  transitoJulgado: text("transito_julgado"),
  responsabilidadeSubsidiaria: text("responsabilidade_subsidiaria"),
  tipoInscricaoResponsavel: text("tipo_inscricao_responsavel"),
  numeroInscricaoResponsavel: text("numero_inscricao_responsavel"),

  // Etapa 2 — Identificação do Trabalhador
  nomeReclamante: text("nome_reclamante").notNull(),
  cpfReclamante: text("cpf_reclamante").notNull(),
  dataNascimento: text("data_nascimento"),
  possuiNisPis: text("possui_nis_pis"),
  nisPis: text("nis_pis"),

  // Etapa 3 — Reconhecimento do Vínculo
  reconhecimentoVinculo: text("reconhecimento_vinculo"),
  matriculaExiste: text("matricula_existe"),
  matricula: text("matricula"),
  categoriaEmpregado: text("categoria_empregado"),
  tipoContrato: text("tipo_contrato"),
  dataAdmissao: text("data_admissao"),
  dataDesligamento: text("data_desligamento"),
  motivoDesligamento: text("motivo_desligamento"),
  avisoPrevio: text("aviso_previo"),
  fgtsDev: text("fgts_dev"),
  contribuicaoPrevidenciaria: text("contribuicao_previdenciaria"),

  // Etapa 4 — Período
  competenciaInicial: text("competencia_inicial"),
  competenciaFinal: text("competencia_final"),

  // Etapa 5 — Tributos
  existeIrrf: text("existe_irrf"),
  existeContribSegurado: text("existe_contrib_segurado"),
  existeContribPatronal: text("existe_contrib_patronal"),
  existeSatGilrat: text("existe_sat_gilrat"),
  existeTerceiros: text("existe_terceiros"),

  // Etapa 6 — Sucessão / Responsabilidade
  existeSucessao: text("existe_sucessao"),
  existeGrupoEconomico: text("existe_grupo_economico"),
  existeResponsabilidadeSolidaria: text("existe_responsabilidade_solidaria"),

  // Etapa 7 — Processos Múltiplos
  multiplosTrabalhadores: text("multiplos_trabalhadores"),
  multiplosPeriodos: text("multiplos_periodos"),
  multiplasCompetencias: text("multiplas_competencias"),

  // Etapa 8 — Finalização
  eventoSeraEnviado: text("evento_sera_enviado"),
  tipoEvento: text("tipo_evento"),
  numeroReciboAnterior: text("numero_recibo_anterior"),

  // Categoria do evento (S-2500 / S-2501 / Ambos)
  categoriaEvento: text("categoria_evento"),

  // 13º Salário (obrigatório para S-2500 e S-2501)
  vrDecimoTerceiro: text("vr_decimo_terceiro"),

  // IRRF
  irTipo: text("ir_tipo"),
  irBase: text("ir_base"),
  irImpDevido: text("ir_imp_devido"),

  // Campos legados mantidos para compatibilidade
  tipoAcao: text("tipo_acao"),
  linkIntegra: text("link_integra"),
  razaoSocialDeclarante: text("razao_social_declarante"),
  cnpjDeclarante: text("cnpj_declarante"),
  tipoInscricaoDeclarante: text("tipo_inscricao_declarante"),
  unidadeNegocioDeclarante: text("unidade_negocio_declarante"),
  tipoProcesso: text("tipo_processo"),
  razaoSocialReclamada: text("razao_social_reclamada"),
  tipoInscricaoReclamada: text("tipo_inscricao_reclamada"),
  cnpjReclamada: text("cnpj_reclamada"),
  dataDistribuicao: text("data_distribuicao"),
  faseAtual: text("fase_atual"),
  comarca: text("comarca"),
  uf: text("uf"),
  vara: text("vara"),
  razaoSocialSindicato: text("razao_social_sindicato"),
  cnpjSindicato: text("cnpj_sindicato"),
  razaoSocialCliente: text("razao_social_cliente"),
  tipoInscricaoCliente: text("tipo_inscricao_cliente"),
  cnpjCliente: text("cnpj_cliente"),
  unidadeNegocioCliente: text("unidade_negocio_cliente"),
  nomeCliente: text("nome_cliente"),
  dataConciliacao: text("data_conciliacao"),
  ambitoConciliacao: text("ambito_conciliacao"),
  gatilhoS2500: text("gatilho_s2500"),
  gatilhoS2500Secundario: text("gatilho_s2500_secundario"),
  obrigacaoDeferida: text("obrigacao_deferida"),
  prazoDeferido: text("prazo_deferido"),
  gatilhoS2501: text("gatilho_s2501"),
  estrategiaCalculos: text("estrategia_calculos"),
  estrategiaQuitacao: text("estrategia_quitacao"),
  fluxoNormalEsocial: text("fluxo_normal_esocial"),
  dataPagamentoContribuicoes: text("data_pagamento_contribuicoes"),
  dataSentencaHomologacao: text("data_sentenca_homologacao"),
  regimeTrabalhista: text("regime_trabalhista"),
  regimePrevidenciario: text("regime_previdenciario"),
  tempoParcial: text("tempo_parcial"),
  statusContrato: text("status_contrato"),
  dataAvisoPrevio: text("data_aviso_previo"),
  reintegracao: text("reintegracao"),
  dataReintegracao: text("data_reintegracao"),
  unicidadeContratual: text("unicidade_contratual"),
  dataUnicidadeContratual: text("data_unicidade_contratual"),
  sucessaoEmpresarial: text("sucessao_empresarial"),
  dataSucessaoEmpresarial: text("data_sucessao_empresarial"),
  reconhecimentoCategoria: text("reconhecimento_categoria"),
  novoCbo: text("novo_cbo"),
  repercussaoProcesso: text("repercussao_processo"),
  remuneracaoBase: text("remuneracao_base"),
  baseDecimoTerceiro: text("base_decimo_terceiro"),

  // Identificação do estabelecimento pagador (Informações do Contrato)
  tipoInscricaoEstabelecimento: text("tipo_inscricao_estabelecimento"),
  numeroInscricaoEstabelecimento: text("numero_inscricao_estabelecimento"),

  // Valores por competência — JSON: { "AAAA-MM": { baseCP, baseCPDecimoTerceiro, preencherFGTS, baseFGTS, baseFGTSSefip, baseFGTSAnterior } }
  competenciaValores: text("competencia_valores"),

  // Controle interno FGTS
  incidenciaFGTS: text("incidencia_fgts"),

  // Transmissão vinculada
  transmissionId: integer("transmission_id"),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertProcessFormSchema = createInsertSchema(processFormsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertProcessForm = z.infer<typeof insertProcessFormSchema>;
export type ProcessForm = typeof processFormsTable.$inferSelect;
